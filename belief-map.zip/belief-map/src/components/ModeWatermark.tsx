export default function ModeWatermark() {
  return <div className="canvas-watermark" aria-hidden="true" />;
}
